<?php
/*
$link = mysqli_connect('localhost', 'mohsin', 'mohsin');
mysqli_select_db($link, 'meyecare');
*/
$link = mysqli_connect('localhost','root','');
mysqli_select_db($link,'eyecare');
?>