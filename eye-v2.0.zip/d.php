<?php
/*
$link = mysqli_connect('localhost', 'mohsin', 'mohsin');
mysqli_select_db($link, 'meyecare');
*/
$con = mysqli_connect('localhost','root','Rakesh@123');
mysqli_select_db($con,'student');
?>
