<?php
    session_start();
    $a = $_SESSION['s_scode'];
    echo $a;
?>